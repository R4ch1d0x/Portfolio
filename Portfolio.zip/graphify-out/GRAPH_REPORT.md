# Graph Report - Portfolio  (2026-11-13)

## Corpus Check
- Corpus is ~42,335 words - fits in a single context window. You may not need a graph.

## Summary
- 63 nodes · 64 edges · 12 communities (7 shown, 5 thin omitted)
- Extraction: 95% EXTRACTED · 5% INFERRED · 0% AMBIGUOUS · INFERRED: 3 edges (avg confidence: 0.95)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- Asset Site Utilities
- Root Site Utilities
- DDoS Concepts and Defense
- HTB Touch Writeup
- Portfolio Projects
- JWT Security Lab
- Touch Vulnerability Themes
- SQL Injection Defenses
- Contact and Profile
- TryHackMe Writeups
- Virtualized Network Security

## God Nodes (most connected - your core abstractions)
1. `Distributed Denial of Service` - 5 edges
2. `Touch` - 5 edges
3. `el()` - 4 edges
4. `line()` - 4 edges
5. `el()` - 4 edges
6. `line()` - 4 edges
7. `JSON Web Token` - 4 edges
8. `Touch` - 4 edges
9. `run()` - 3 edges
10. `run()` - 3 edges

## Surprising Connections (you probably didn't know these)
- `Touch` --semantically_similar_to--> `Touch`  [INFERRED] [semantically similar]
  meta/htb-touch-writeup.md → writeups/HTB/touch-writeup.html
- `Safe Shelter Connect Comparative Security Audit` --semantically_similar_to--> `Safe Shelter Connect`  [INFERRED] [semantically similar]
  projects.html → index.html
- `AES Counter-Mode Implementation` --semantically_similar_to--> `AES in Counter Mode`  [INFERRED] [semantically similar]
  projects.html → index.html
- `DDoS Simulator` --references--> `DDoS Simulator Lab`  [EXTRACTED]
  index.html → labs/index.html
- `JWT Forgery Lab` --references--> `JWT Forgery Lab`  [EXTRACTED]
  index.html → labs/index.html

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **DDoS Concepts, Detection, and Defense** — labs_lab_ddos_denial_of_service, labs_lab_ddos_distributed_denial_of_service, labs_lab_ddos_service_availability, labs_lab_ddos_ddos_detection, labs_lab_ddos_ddos_defense_in_depth [EXTRACTED 1.00]
- **SQL Injection Understanding, Detection, and Remediation** — labs_sql_injection_sql_injection, labs_sql_injection_parameterized_queries, labs_sql_injection_least_privilege_database_accounts, labs_sql_injection_sql_injection_detection [EXTRACTED 1.00]
- **Touch Writeup Security Themes** — meta_htb_touch_writeup_touch, meta_htb_touch_writeup_credential_exposure, meta_htb_touch_writeup_windows_kiosk_escape, meta_htb_touch_writeup_mysql_udf_privilege_escalation, meta_htb_touch_writeup_trusted_plugin_directory_permissions [EXTRACTED 1.00]

## Communities (12 total, 5 thin omitted)

### Community 0 - "Asset Site Utilities"
Cohesion: 0.36
Nodes (5): complete(), el(), line(), linkLine(), run()

### Community 1 - "Root Site Utilities"
Cohesion: 0.36
Nodes (5): complete(), el(), line(), linkLine(), run()

### Community 2 - "DDoS Concepts and Defense"
Cohesion: 0.29
Nodes (4): DDoS Simulator, DDoS Simulator Lab, Denial of Service, Distributed Denial of Service

### Community 3 - "HTB Touch Writeup"
Cohesion: 0.29
Nodes (7): Hack The Box Touch Writeup, Touch, MySQL UDF Privilege Escalation, Nexion DeviceHub, Touch, Windows Kiosk Escape, Hack The Box

### Community 4 - "Portfolio Projects"
Cohesion: 0.33
Nodes (6): AES in Counter Mode, ENSIASD, Rachid Chokrani, Safe Shelter Connect, AES Counter-Mode Implementation, Safe Shelter Connect Comparative Security Audit

### Community 5 - "JWT Security Lab"
Cohesion: 0.40
Nodes (4): JWT Forgery Lab, JWT Forgery Lab, Broken Access Control, JSON Web Token

### Community 6 - "Touch Vulnerability Themes"
Cohesion: 0.40
Nodes (5): Credential Exposure, MySQL UDF Privilege Escalation, Nexion DeviceHub, Touch, Windows Kiosk Escape

## Knowledge Gaps
- **15 isolated node(s):** `Rachid Chokrani`, `ENSIASD`, `DDoS Simulator`, `JWT Forgery Lab`, `Hack The Box Touch Writeup` (+10 more)
  These have ≤1 connection - possible missing edges. (Counts symbols only; 33 node(s) total have ≤1 connection when file, concept and rationale nodes are included.)
- **5 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Touch` connect `HTB Touch Writeup` to `Touch Vulnerability Themes`?**
  _High betweenness centrality (0.025) - this node is a cross-community bridge._
- **What connects `Rachid Chokrani`, `ENSIASD`, `DDoS Simulator` to the rest of the system?**
  _15 weakly-connected nodes found - possible missing edges._
- **Why does `Touch` connect `Touch Vulnerability Themes` to `HTB Touch Writeup`?**
  _High betweenness centrality (0.022) - this node is a cross-community bridge._